import pandas as pd
import time
from geopy.geocoders import Nominatim

# Define the list of locations you want to geocode
locations = ["Auto Nagar","Bachupally","Bahadurpally","Balanagar","Bandlaguda Jagir","Banjara Hills","Bapu Nagar",
"Beeramguda","Begumpet","Boduppal","Bolarum","Bowenpally","Bowrampet","Budvel","Chandanagar","Dammaiguda",
"Dilsukh Nagar"]

# Create a geocoder object
geolocator = Nominatim(user_agent="my_app")

# Geocode the locations and store the results in a list of dictionaries
geocoded_locations = []
for location_name in locations:
    time.sleep(1)
    location = geolocator.geocode(location_name)
    time.sleep(1)
    if location:
        geocoded_locations.append({
            "name": location_name,
            "latitude": location.latitude,
            "longitude": location.longitude
        })
    else:
        print(f"Unable to geocode {location_name}")

# Create a DataFrame from the list of dictionaries
df = pd.DataFrame(geocoded_locations)

# Write the DataFrame to a CSV file
df.to_csv("geocoded_locations_hyderabad.csv", index=False)

# Print the first few rows of the DataFrame to verify that the data was written correctly

